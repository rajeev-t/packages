// point_3d.h

// we don't compile header files

#ifndef POINT3D_H
#define POINT3D_H

#include <cmath>
#include <iostream>
#include <vector>

/**
 * @brief Point3D helper class. Provides method for distance
 *
 */
class Point3D {
  private:
    double m_x;
    double m_y;
    double m_z;

  public:
    /**
     * @brief Delete default constructor. Must pass arguments
     *
     */
    Point3D() = delete;

    /**
     * @brief Construct a new Point 3 D object
     *
     * @param x
     * @param y
     * @param z
     */
    Point3D(double x, double y, double z);

    /**
     * @brief Destroy the Point 3 D object
     *
     */
    ~Point3D();

    /**
     * @brief Get the distance from object
     *
     * @param x
     * @param y
     * @param z
     * @return double
     */
    double get_distance_from(double x, double y, double z);

    /**
     * @brief Get the angles object
     *
     * @return std::vector<double>
     */
    std::vector<double> get_angles();
};

#endif